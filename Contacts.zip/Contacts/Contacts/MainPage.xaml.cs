﻿using System;
using System.IO;
using Microsoft.Maui;
using Microsoft.Maui.Controls;
using CSharpShellCore;
using Contacts;

namespace Contacts
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();


        }
        public void puched_click(Object sender, EventArgs e)
        {
            if (!File.Exists("contacts.json"))
                File.Create("contacts.json");
            String data = File.ReadAllText("contacts.json");
            if (data == "" || data == null)
                File.WriteAllText("contacts.json", fName.Text + "," + lName.Text + "," + emailtxt.Text + "," + phonetxt.Text + "," + addresstxt.Text + "," + postaltxt.Text + "," + citytxt.Text);
            else
                File.WriteAllText("contacts.json", data + ";" + fName.Text + "," + lName.Text + "," + emailtxt.Text + "," + phonetxt.Text + "," + addresstxt.Text + "," + postaltxt.Text + "," + citytxt.Text);


        }
        public void viewContact_click(Object sender, EventArgs e)
        {
            Navigation.PushAsync(new pgtow());



        }
    }
}