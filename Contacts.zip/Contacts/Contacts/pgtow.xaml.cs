﻿using System;
using System.IO;
using Microsoft.Maui;
using Microsoft.Maui.Controls;

namespace Contacts
{
    public partial class pgtow : ContentPage
    {
        public pgtow()
        {
            InitializeComponent();
            String data = File.ReadAllText("contacts.json");
            String[] jsonData = data.ToString().Split(";");
            StackLayout stk = new StackLayout();
            for (int i = 0; i < jsonData.Length; i++)
            {
                String[] jsons = jsonData[i].ToString().Split(",");

                Label l = new Label { Margin = 3, Text = Convert.ToString(i) + " \nfirst name : " + jsons[0] + " \nlast name : " + jsons[1] + " \nemail : " + jsons[2] + " \nphone : " + jsons[3] + " \naddress : " + jsons[4] + " \npostal code : " + jsons[5] + " \ncity : " + jsons[6] };
                stk.Add(l);


            }
            Content = stk;
        }
    }
}